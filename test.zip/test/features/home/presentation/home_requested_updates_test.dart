import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:orbit_ui/features/home/domain/models/home_models.dart';
import 'package:orbit_ui/features/home/presentation/screens/home_screen.dart';
import 'package:orbit_ui/features/home/presentation/widgets/promo_banner_card.dart';

void main() {
  Future<void> setPhoneSize(WidgetTester tester, Size size) async {
    await tester.binding.setSurfaceSize(size);
    addTearDown(() => tester.binding.setSurfaceSize(null));
  }

  Widget wrap(Widget child) => MaterialApp(home: child);

  testWidgets(
    'four quick actions fill the available Home content width evenly',
    (tester) async {
      await setPhoneSize(tester, const Size(390, 844));
      await tester.pumpWidget(wrap(HomeScreen.demo()));
      await tester.pumpAndSettle();

      final cards = <Finder>[
        find.byKey(const ValueKey<String>('quick_action_ping')),
        find.byKey(const ValueKey<String>('quick_action_sos')),
        find.byKey(const ValueKey<String>('quick_action_explore')),
        find.byKey(const ValueKey<String>('quick_action_moment')),
      ];
      final rects = cards.map(tester.getRect).toList();

      expect(rects.first.left, closeTo(15, 0.01));
      expect(rects.last.right, closeTo(375, 0.01));
      for (var index = 1; index < rects.length; index++) {
        expect(rects[index].left - rects[index - 1].right, closeTo(10, 0.01));
        expect(rects[index].width, closeTo(rects.first.width, 0.01));
      }
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'quick actions remain horizontally scrollable with backend growth',
    (tester) async {
      await setPhoneSize(tester, const Size(320, 568));
      final actions = List<QuickActionData>.generate(
        12,
        (index) => QuickActionData(
          id: 'dynamic_$index',
          title: 'Backend Action $index',
          icon: Icons.star_outline_rounded,
          iconColor: const Color(0xFF7C3AED),
          iconBackground: const Color(0xFFF2EAFE),
        ),
      );
      final demo = HomeScreen.demo();
      await tester.pumpWidget(
        wrap(
          HomeScreen(
            greetingName: 'Emma',
            quickActions: actions,
            upcomingPlans: demo.upcomingPlans,
            promoBanner: demo.promoBanner,
            favoritePeople: demo.favoritePeople,
            recentMoments: demo.recentMoments,
            onNotificationPressed: () {},
            onQuickActionPressed: (action) {},
            onPlanPressed: (plan) {},
            onPromoPressed: () {},
            onFavoritePersonPressed: (person) {},
            onFavoriteToggle: (person) {},
            onMomentPressed: (moment) {},
            onTabSelected: (index) {},
            onAddPressed: () {},
          ),
        ),
      );
      await tester.pumpAndSettle();

      expect(find.text('Backend Action 0'), findsOneWidget);
      await tester.drag(
        find.byKey(HomeKeys.quickActionsList),
        const Offset(-500, 0),
      );
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets('promo logo to title gap is 10px and title is 16 semibold', (
    tester,
  ) async {
    await setPhoneSize(tester, const Size(390, 844));
    const data = PromoBannerData(
      id: 'promo',
      backgroundImagePath: 'assets/banner.png',
      logoImagePath: 'assets/bannerlogo.png',
      title: 'Get there together',
      subtitle: 'Ride with friends',
    );
    await tester.pumpWidget(wrap(PromoBannerCard(data: data, onTap: () {})));
    await tester.pumpAndSettle();

    final logoRect = tester.getRect(find.byKey(PromoBannerKeys.logo));
    final titleRect = tester.getRect(find.byKey(PromoBannerKeys.title));
    final title = tester.widget<Text>(find.byKey(PromoBannerKeys.title));

    expect(titleRect.top - logoRect.bottom, closeTo(10, 0.01));
    expect(title.style?.fontSize, 16);
    expect(title.style?.fontWeight, FontWeight.w600);
    expect(tester.takeException(), isNull);
  });

  testWidgets('favorite heart defaults outlined and toggles both directions', (
    tester,
  ) async {
    await setPhoneSize(tester, const Size(390, 844));
    FavoritePersonData? reported;
    final demo = HomeScreen.demo();
    await tester.pumpWidget(
      wrap(
        HomeScreen(
          greetingName: demo.greetingName,
          quickActions: demo.quickActions,
          upcomingPlans: demo.upcomingPlans,
          promoBanner: demo.promoBanner,
          favoritePeople: const <FavoritePersonData>[
            FavoritePersonData(
              id: 'emma',
              name: 'Emma',
              status: 'Active now',
              imagePath: 'assets/Emma.png',
            ),
          ],
          recentMoments: demo.recentMoments,
          onNotificationPressed: () {},
          onQuickActionPressed: (action) {},
          onPlanPressed: (plan) {},
          onPromoPressed: () {},
          onFavoritePersonPressed: (person) {},
          onFavoriteToggle: (person) => reported = person,
          onMomentPressed: (moment) {},
          onTabSelected: (index) {},
          onAddPressed: () {},
        ),
      ),
    );
    await tester.pumpAndSettle();

    await tester.scrollUntilVisible(
      find.bySemanticsLabel('Add Emma to favorites'),
      240,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.pumpAndSettle();

    expect(find.byIcon(Icons.favorite_border_rounded), findsOneWidget);
    await tester.tap(find.bySemanticsLabel('Add Emma to favorites'));
    await tester.pump();
    expect(find.byIcon(Icons.favorite_rounded), findsOneWidget);
    expect(reported?.isFavorite, isTrue);

    await tester.tap(find.bySemanticsLabel('Remove Emma from favorites'));
    await tester.pump();
    expect(find.byIcon(Icons.favorite_border_rounded), findsOneWidget);
    expect(reported?.isFavorite, isFalse);
    expect(tester.takeException(), isNull);
  });
}
